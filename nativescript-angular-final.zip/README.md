# Proyecto Final NativeScript + Angular

Este proyecto cumple con los 10 puntos solicitados en la entrega del módulo.

1. Basado en template drawer-navigation.
2. Dos componentes nuevos: `perfil`, `testimonios`.
3. Módulo nuevo: `perfil`.
4. Submódulo de rutas para `perfil`.
5. Integración con el side drawer.
6. Servicio `UserService` inyectado globalmente.
7. Uso de `ngFor` en `testimonios`.
8. Estilos por plataforma.
9. Ícono personalizado.
10. Código condicional para Android en `perfil`.
