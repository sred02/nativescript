import { Component } from '@angular/core';
import { isAndroid } from '@nativescript/core';

@Component({
  selector: 'ns-perfil',
  templateUrl: './perfil.component.html',
})
export class PerfilComponent {
  mensaje: string = '';
  constructor() {
    if (isAndroid) {
      this.mensaje = 'Este es un mensaje exclusivo para Android.';
    }
  }
}